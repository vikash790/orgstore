# Realtime pizza app using Node-express-mongo-socket.io

![Realtime Pizza app](https://github.com/codersgyan/realtime-pizza-app-node-express-mongo/blob/master/Screenshot%202020-09-21%20at%2023.03.06.png?raw=true)




## Installation 
After download or clone run `npm install` OR `yarn install` to install all the dependancies.

🙏 If you find this repo helpful then don't forget to give a start ❇️ to this repository. :)
